#!/usr/bin/env python
import json, os, wget , glob
import docker
from docker.errors import DockerException
from pprint import pprint
import subprocess
from scalr.client import ScalrApiClient
import scalr
from io import BytesIO
from docker import APIClient
import LogsForwarding
c=LogsForwarding.LogsForwarding()

class BuildOn(object):
    def __init__(self, data):
        self.dockerenv = docker.from_env()
        self.username = 'devopsbasservice/'
        self.commit_id = format(data['commits'][0]['id'])[0:7]

	unique = format(data['ref'])
        self.tuid = unique.split("/")[2] ##taking only the branch name eliminating ref/heads
	self.tagid = self.tuid + self.commit_id
        self.ttuid = self.tuid.lower()
        self.uid = self.ttuid + "-" + self.commit_id
        
	self.repo_name = format(data['repository']['name'])
        self.image_id = self.username + self.repo_name
#        self.msnodefldr = self.repo_name + "_" + self.commit_id
        self.msnodefldr = self.repo_name + "_" + self.uid
        self.buildpath = '/home/ubuntu/temp_builds/'
        self.dockerfilepath = self.buildpath + self.msnodefldr
        self.tag = self.image_id + ":" + self.uid

    def dockerbuild(self):
            print self.tag, self.dockerfilepath 
            print "started to build"
	
	    print self.tuid
	    print self.ttuid
            print self.uid

            images=  self.dockerenv.images.build(path=self.dockerfilepath, tag=self.tag, stream=False, rm=True)
	    res=images.save()
            print  "build complete"

    def dockerpush(self):
            print "started to  push" 
            client = APIClient(base_url='unix://var/run/docker.sock')
	    for line in client.push(self.tag, stream=True):
                print line
            print "push complete"

    def setup(self, data):
        if not os.path.exists(self.dockerfilepath):
            os.makedirs(self.dockerfilepath)
            ref = format(data['ref'])
            branch = ref.split("/")
            branch = branch.pop()
            try:
                wget.download("https://raw.githubusercontent.com/" + format(
                    data['repository']['full_name']) + "/" + branch + "/" + "Dockerfile", out=self.dockerfilepath)
                wget.download("https://raw.githubusercontent.com/" + format(
                    data['repository']['full_name']) + "/" + branch + "/" + "job.yaml", out=self.dockerfilepath)
                wget.download("https://raw.githubusercontent.com/" + format(
                    data['repository'][
                        'full_name']) + "/" + branch + "/" + "jenkins.plugins.logstash.LogstashInstallation.xml",
                              out=self.dockerfilepath)
                wget.download("https://raw.githubusercontent.com/" + format(
                    data['repository']['full_name']) + "/" + branch + "/" + "kube.yaml", out=self.dockerfilepath)
                wget.download("https://raw.githubusercontent.com/" + format(
                    data['repository']['full_name']) + "/" + branch + "/" + "com.hpi.ScalrJenkins.ScalrJenkins.xml", out=self.dockerfilepath)
            except NameError:
                raise ConnectionError(
                    "Error in downloading files from SCM - Dockerfile , job.yaml and "
                    "jenkins.plugins.logstash.LogstashInstallation.xml"
                )
            try:
                self.replacestring(self.dockerfilepath + "/job.yaml", "<appndid>", self.uid)
                filehandle = open(self.dockerfilepath + "/job.yaml", "r+")
                linelist = filehandle.readlines()
                baseimage = linelist[len(linelist) - 1].split(":")
                print(baseimage[1].strip())
                self.replacestring (self.dockerfilepath + "/Dockerfile", "<NAME>", baseimage.pop().strip())
                self.replacestring (self.dockerfilepath +"/kube.yaml", "<tagid>", self.uid)
                self.replacestring (self.dockerfilepath +"/kube.yaml", "<image>", self.tag)
                self.dockerbuild()
                self.dockerpush() 
                os.system("kubectl create -f "+self.dockerfilepath +"/kube.yaml")
		print "*****Pods created ******"
		c.FwdLogs(self.commit_id)
		print "Started pushing Logs"
            except NameError:
                raise BuildOn(
                    "Error in replacing <appid> in job.yaml or <NAME> in Dockerfile"
                ) 

    @staticmethod
    def replacestring (filepath, orgstring, replacestring):
        if os.path.isfile(filepath):
            filehandle = open(filepath, "r+")
            lines = filehandle.read()
            lines = lines.replace(orgstring, replacestring)
            filehandle.close()
            filehandle = open(filepath, "w")
            filehandle.write(lines)
            filehandle.close()
        else:
            print('File not found{}'.filepath)


    #def deploy(self,data):
     #   role = json.loads(open('deploy.json').read())
	  #  client = ScalrApiClient(scalr.api_url.rstrip("/"), scalr.api_key_id, scalr.api_key_secret)
        #client.create("/api/v1beta0/user/{}/farms/{}/farm-roles".format(scalr.env_id, scalr.farm_id), json=role, verify=False)
         
