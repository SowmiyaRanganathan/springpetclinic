import json
import requests
from elasticsearch import Elasticsearch
import datetime

##To bypass ELK ssl valdiation
requests.packages.urllib3.disable_warnings()


##Connect to ELK cluster
es = Elasticsearch('https://54.144.242.188:9200',verify=False,verify_certs=False)


time=datetime.datetime.now()

## Form index name with current date
date=datetime.date.today()

##Convert datetime object to string
datestr=date.strftime('%m.%d.%Y')

indexName='kubernetes'+'-'+datestr


## post data to ELK
es.index(index= indexName, doc_type='post', id='',  body={ "@timestamp": time,'KubernetsLog': 'Jenkins is fully up and running.Build Success.'})
#es.indices.refresh(index=date1)
