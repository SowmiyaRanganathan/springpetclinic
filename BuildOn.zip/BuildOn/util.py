#!/usr/bin/env python

import json
import sys
import requests.exceptions

import requests
import requests.auth
import ssl
import scalr
from api.client import ScalrApiClient


def get_env_servers(client, envId):
    servers_path = '/api/v1beta0/user/{envId}/servers/?status=running'.format(envId=envId)
    servers = client.list(servers_path, verify=False)
    farmIds = []
    farmRoleIds = []
    for s in servers:
        farmIds.append(s['farm']['id'])
        farmRoleIds.append(s['farmRole']['id'])
    farmIds = set(farmIds)
    farmRoleIds = set(farmRoleIds)

    farms = {}
    farm_path = '/api/v1beta0/user/{envId}/farms/{farmId}/'
    for farmId in farmIds:
        path = farm_path.format(envId=envId, farmId=farmId)
        farms[farmId] = client.fetch(path)

    farmRoles = {}
    farmRole_path = '/api/v1beta0/user/{envId}/farm-roles/{farmRoleId}/'
    for farmRoleId in farmRoleIds:
        path = farmRole_path.format(envId=envId, farmRoleId=farmRoleId)
        farmRoles[farmRoleId] = client.fetch(path)

    result = {'_meta':
                  {'hostvars': {}}
              }
    for farmId, farm in farms.iteritems():
        result[farm['name']] = {'vars': {
            'id': farmId,
            'project': farm['project']['id'],
            'owner': farm['owner']['id']
        },
            'children': []}
        for farmRoleId, farmRole in farmRoles.iteritems():
            if farmRole['farm']['id'] != farmId:
                continue
            farmRoleGroupId = 'farm-role-' + str(farmRoleId) + '-' + farmRole['alias']
            result[farm['name']]['children'].append(farmRoleGroupId)
            result[farmRoleGroupId] = {'hosts': [], 'vars': {
                'id': farmRoleId,
                'platform': farmRole['platform'],
                'roleId': farmRole['role']['id']
            }}
            for server in servers:
                if server['farmRole']['id'] != farmRoleId:
                    continue
                if len(server['publicIp']) == 0:
                    # Server has no public IP
                    continue
                result[farmRoleGroupId]['hosts'].append(server['publicIp'][0])
                result['_meta']['hostvars'][server['publicIp'][0]] = {'hostname': server['hostname']}
    print json.dumps(result, indent=2)


def get_farm_servers(client, envId, farmId):
    servers_path = '/api/v1beta0/user/{envId}/farms/{farmId}/servers/?status=running'.format(envId=envId, farmId=farmId)
    servers = client.list(servers_path, verify=False)

    farmRoleIds = []
    for s in servers:
        farmRoleIds.append(s['farmRole']['id'])
    farmRoleIds = set(farmRoleIds)

    farm_path = '/api/v1beta0/user/{envId}/farms/{farmId}/'.format(envId=envId, farmId=farmId)
    farm = client.fetch(farm_path)

    farmRoles = {}
    farmRole_path = '/api/v1beta0/user/{envId}/farm-roles/{farmRoleId}/'
    for farmRoleId in farmRoleIds:
        path = farmRole_path.format(envId=envId, farmRoleId=farmRoleId)
        farmRoles[farmRoleId] = client.fetch(path)

    result = {'_meta':
                  {'hostvars': {}}
              }

    for farmRoleId, farmRole in farmRoles.iteritems():
        farmRoleGroupId = 'farm-role-' + str(farmRoleId) + '-' + farmRole['alias']
        result[farmRoleGroupId] = {'hosts': [], 'vars': {
            'id': farmRoleId,
            'platform': farmRole['platform'],
            'roleId': farmRole['role']['id']
        }}
        for server in servers:
            if server['farmRole']['id'] != farmRoleId:
                continue
            if len(server['publicIp']) == 0:
                # Server has no public IP
                continue
            result[farmRoleGroupId]['hosts'].append(server['publicIp'][0])
            result['_meta']['hostvars'][server['publicIp'][0]] = {'hostname': server['hostname']}
    print json.dumps(result, indent=2)


def create_farm(client, env_id):
    servers_path = "/api/v1beta0/user/{0}/farms/".format(env_id)
    try:
        res = client.create(servers_path, json=scalr.farm, verify=False)
    except Exception, e:
        sys.stderr.write("Create Farm Failed - Could not access {}. Exception: {}\n".format(servers_path, str(e)))
    else:
        return res['id']


def add_server(client, farmrole_id):
    servers_path = "/api/v1beta0/user/{0}/farm-roles/{1}/servers/".format(scalr.env_id, farmrole_id)
    try:
        res = client.create(servers_path, json=scalr.addfarmrole, verify=False)
    except Exception, e:
        sys.stderr.write("Add Farmrole Failed - Could not access {}. Exception: {}\n".format(servers_path, str(e)))
    else:
        return res['id']


def change_gv(client, server_id):
    servers_path = servers_path = "/api/v1beta0/user/{0}/servers/{1}/global-variables/NexusURL/".format(scalr.env_id, server_id)
    try:
        res = client.patch(servers_path, json=scalr.gvnexus, verify=False)
    except Exception, e:
        sys.stderr.write("Add Farmrole Failed - Could not access {}. Exception: {}\n".format(servers_path, str(e)))
    else:
        return True

def farmlaunch(client, env_id, farm_id):
    servers_path = "/api/v1beta0/user/{0}/farms/{1}/actions/launch/".format(env_id, farm_id)
    try:
        res = client.post(servers_path, verify=False)
    except Exception, e:
        sys.stderr.write("Add Farmrole Failed - Could not access {}. Exception: {}\n".format(servers_path, str(e)))
    else:
        return True

def restart_server(client, env_id, server_id):
    servers_path = "/api/v1beta0/user/{0}/servers/{1}/actions/reboot/".format(env_id, server_id)
    try:
        res = client.patch(servers_path, verify=False)
    except Exception, e:
        sys.stderr.write("Reboot Failed - Could not access {}. Exception: {}\n".format(servers_path, str(e)))
    else:
        return True

client = ScalrApiClient(scalr.api_url.rstrip("/"), scalr.api_key_id, scalr.api_key_secret)
server_id = add_server(client, scalr.farmrole_id)
print (server_id)
#create_farm(client,"1")
change_gv(client, server_id)
#restart_server(client,scalr.env_id,server_id)
#farmlaunch(client,scalr.env_id,scalr.farm_id)

#main('https://scalr.cogdevops.com/', 'APIK9XUQ1702R1E90LA2', 'zmnxRJs3zE5awYLNzwkaSRgZkj2WtsokTvUDZgla', '1', '168')
