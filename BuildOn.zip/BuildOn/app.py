import glob
import json
import os

from flask import Flask, render_template, request, redirect, url_for

from buildon import BuildOn

app = Flask(__name__)

# This is the path to the upload directory
app.config['UPLOAD_FOLDER'] = '/home/ubuntu/temp_builds/'
# These are the extension that we are accepting to be uploaded
app.config['ALLOWED_EXTENSIONS'] = set(['log', 'yaml', 'yml', 'json', 'xml', 'txt'])


# For a given file, return whether it's an allowed type or not
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1] in app.config['ALLOWED_EXTENSIONS']


# This route will show a form to perform an AJAX request
# jQuery is loaded to execute the request and update the
# value of the operation
@app.route('/')
def index():
    return Response('started'),200
# Route that will process the file upload
@app.route('/upload', methods=['POST'])
def upload():
    # Get the name of the uploaded file
    file = request.files['file']
    # Check if the file is one of the allowed types/extensions
    if file and allowed_file(file.filename):
        # Make the filename safe, remove unsupported chars
        filename = file.filename
        # Move the file form the temporal folder to
        # the upload folder we setup
        #app.config['UPLOAD_FOLDER'] = glob.glob(app.config['UPLOAD_FOLDER'] + '*' + filename.rsplit('.', 1)[0])[0]
        Uploadpath = glob.glob(app.config['UPLOAD_FOLDER'])[0] + '*' + filename.rsplit('.', 1)[0]
        print (Uploadpath)
        print (glob.glob(Uploadpath)[0])
        Uploadpath= glob.glob(Uploadpath)[0]
        file.save(os.path.join(Uploadpath, filename))
    return 'ok'



@app.route('/setup', methods=['POST'])
def setup():
    data = json.loads(request.data)
    build = BuildOn(data)
    build.setup(data)
    print "Pod completed"
    return "ok"

@app.route('/deploy', methods=['POST'])
def deploy():
    data = json.loads(request.data)
    build = BuildOn(data)
    build.deploy(data)
    return "ok"
app.run(host='0.0.0.0',port=5000, debug='TRUE')
