#!/usr/bin/env python
import json, os, wget , glob
from io import BytesIO
from docker import APIClient
import docker
from docker.errors import DockerException
from pprint import pprint
import subprocess
from scalr.client import ScalrApiClient
import scalr

#client = docker.from_env()
client = APIClient(base_url='unix://var/run/docker.sock')
dockerfilepath ="/home/ubuntu/temp_builds/springpetclinic_908dcb8"
tag = "test"
#images=  client.images.build(path=dockerfilepath, tag=tag, stream=False, rm=True)
#res = images.save
#    print line
for line in client.push('devopsbasservice/springpetclinic:cd9a8c4', stream=True):
    print line

