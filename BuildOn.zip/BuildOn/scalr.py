#Scalr Variables
api_url= "https://scalr.cogdevops.com"
api_key_id= "APIK64U718A2S7X5HJAI"
api_key_secret= "LlxOAB/cqMp1LCqgtHh6s0syZu0/3FKLiqoy6Ci4"
env_id= "1"
farm_id= "224"
farmrole_id = "570"

#Create Farm ID
farm = {
    "description": "Testk8d",
    "launchOrder": "sequential",
    "name": "Testk8d",
    "project": {
        "id": "4466f1e7-5a00-4870-939d-8f16f06a3232"
    },
    "teams": [
        {
            "id": 1
        }
    ],
    "timezone": "Asia/Kolkata"
}


#Add Farm Role <tagid>
addfarmrole= {
  "alias": "Test123",
  "instance": {
    "instanceConfigurationType": "AwsInstanceConfiguration",
    "instanceType": {
      "id": "t2.medium"
    }
  },
  "placement": {
    "placementConfigurationType": "AwsVpcPlacementConfiguration",
    "region": "us-east-1",
    "subnets": [
     {
       "id": "subnet-b64862c0"
     }
    ],
    "vpc": {
      "id": "vpc-8814ffec"
    }
  },
  "platform": "ec2",
  "role": {
    "id": 83119
  },
  "scaling": {
      "enabled": "false",
      "minInstances": 1,
      "maxInstances": 1,
      "scalingBehavior": "launch-terminate",
      "considerSuspendedServers": "running",
      "rules": []
  }
}

#Change Nexus Global Variable
gvnexus = {
  "value": "http://204.236.215.231:8081/nexus/content/repositories/samplerepo/2f39585.war"
}

#Launch Farm
#POST /api/v1beta0/user/envId/farms/farmId/actions/launch/
#"value": "http://204.236.215.231:8081/nexus/content/repositories/samplerepo/2f39585.war"