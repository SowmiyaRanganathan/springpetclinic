#!/usr/bin/env python
import os
import json
import requests
from elasticsearch import Elasticsearch
import datetime

class LogsForwarding:
	def FwdLogs(self,commit):
		result = os.popen("curl -k `(kubectl config view | grep server | cut -f 2- -d \":\" | tr -d \" \")`/api/v1/namespaces/default/pods --header \"Authorization: Bearer `(kubectl describe secret $(kubectl get secrets | grep default | cut -f1 -d ' ') | grep -E '^token' | cut -f2 -d':' | tr -d '\t')`\"").read()

		resp_dict = json.loads(result)

		commit_id = commit
		pod_name = ''

		for i in resp_dict['items']:
			#print i['metadata']['name']
			if commit_id in i['metadata']['name']:
				pod_name = i['metadata']['name']

		#print "=============="
		print pod_name

		logs = os.popen("curl -k `(kubectl config view | grep server | cut -f 2- -d \":\" | tr -d \" \")`/api/v1/namespaces/default/pods/"+pod_name+"/log --header \"Authorization: Bearer `(kubectl describe secret $(kubectl get secrets | grep default | cut -f1 -d ' ') | grep -E '^token' | cut -f2 -d':' | tr -d '\t')`\"").read()
		#print logs

		## skip ELK ssl valdiation
		requests.packages.urllib3.disable_warnings()
		##Connect to ELK cluster
		es = Elasticsearch('https://54.144.242.188:9200',verify=False,verify_certs=False)
		time=datetime.datetime.now()
		## Form index name with current date
		date=datetime.date.today()
		#print(date)
		##Convert datetime object to string
		datestr=date.strftime('%Y.%m.%d')
		#print datestr
		indexName='logstash'+'-'+datestr
		#print(indexName)
		## post data to ELK
		es.index(index= indexName, doc_type='post', id='',  body={ "@timestamp": time,'KubernetsLog': logs})   

